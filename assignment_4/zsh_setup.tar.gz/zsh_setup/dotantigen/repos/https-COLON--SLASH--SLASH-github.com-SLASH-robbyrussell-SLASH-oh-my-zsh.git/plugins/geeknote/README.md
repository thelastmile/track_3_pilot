## ZSH-Geeknote

[Geeknote](https://github.com/VitaliyRodnenko/geeknote) plugin for [oh-my-zsh framework](http://github.com/robbyrussell/oh-my-zsh).

Plugins provides:

- auto completion of commands and their options
- alias `gn`

You can find information how to install Geeknote and it's available commands on the [project website](http://www.geeknote.me/).

Maintainer : Ján Koščo ([@s7anley](https://twitter.com/s7anley))
