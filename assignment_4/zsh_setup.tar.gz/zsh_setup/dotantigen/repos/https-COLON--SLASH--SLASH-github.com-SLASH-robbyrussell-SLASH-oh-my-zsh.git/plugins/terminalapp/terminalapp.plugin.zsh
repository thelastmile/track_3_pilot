# This file is intentionally empty.
#
# The terminalapp plugin is deprecated and may be removed in a future release.
# Its functionality has been folded in to the core lib/termsupport.zsh, which
# is loaded for all users. You can remove terminalapp from your $plugins list
# once all your systems are updated to the current version of Oh My Zsh.
